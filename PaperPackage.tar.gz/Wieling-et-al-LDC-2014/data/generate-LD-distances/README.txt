## Generating the Levenshtein distances:
# 1. Install and compile L04 (source included, downloaded from: http://www.let.rug.nl/kleiweg/L04/)
# 2. Convert the csv file to the L04 format (stored in folder tmp): 
#       tbl2l04.py allprons.csv 
# 3. Tokenize the data (use features-pmi.txt to distinguish aspiration and lengthening, use features-pmi-nodiacs otherwise):
#       cd tmp 
#       features -g -t list-of-tokens.txt ../features-pmi-nodiacs.txt *.data
# 4. Calculate the Levenshtein distances using the PMI-based Levenshtein distance. 
#    Through the option -v, the small fractional value (1e-80) is set which is added to the frequencies
#    thereby preventing frequencies of zero. This low value effectively ensures that sounds which do 
#    not occur in the first iteration of the PMI procedure never align in subsequent iterations as 
#    their PMI-distance is very high.
#       leven-r -a 1 -v 1e-80 -S sounddistances.dif -N 5 -n 990 -l LABELS.txt -s features.table.out -o distances.dif *.ftr
# 5. Convert the results to tabular format
#       dif2tab -o distances.txt distances.dif
# 6. The results are present in the first two columns of the file distances.txt
#    (column 1: speaker, column 2: average LD with respect to the 115 American English speakers)
